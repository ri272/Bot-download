#!/bin/bash
python3 safe_bot_with_limit.py
